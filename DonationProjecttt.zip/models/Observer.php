<?php
// models/Observer.php

interface Observer {
    public function update($data);
}
