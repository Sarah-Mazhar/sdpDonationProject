<!-- views/login.php -->
<form action="/DonationProjecttt/index.php?action=login&login_type=email" method="post">
    <label>Email:</label>
    <input type="email" name="email" required>
    <label>Password:</label>
    <input type="password" name="password" required>
    <button type="submit">Login</button>
</form>
