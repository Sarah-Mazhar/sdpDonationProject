<!-- views/success.php -->
<h1>Welcome, User!</h1>
