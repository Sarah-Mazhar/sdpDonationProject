<!-- views/login_mobile.php -->
<form action="/DonationProjecttt/index.php?action=login&login_type=mobile" method="post">
    <label>Mobile:</label>
    <input type="text" name="mobile" required>
    <label>Password:</label>
    <input type="password" name="password" required>
    <button type="submit">Login</button>
</form>
