<!-- views/signup.php -->
<form action="/DonationProjecttt/index.php?action=signup" method="post">
    <label>Email:</label>
    <input type="email" name="email" required>
    <label>Password:</label>
    <input type="password" name="password" required>
    <label>Mobile:</label>
    <input type="text" name="mobile" required>
    <button type="submit">Sign Up</button>
</form>
